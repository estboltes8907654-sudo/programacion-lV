const usersContainer = document.getElementById("users-container");
const reloadBtn = document.getElementById("reload-btn");
const apiTitle = document.getElementById("api-title");

// Función para mostrar estado de carga
function showLoading() {
    usersContainer.innerHTML = '<div class="loading">⏳ Cargando usuarios...</div>';
}

// Función para mostrar error
function showError(message) {
    usersContainer.innerHTML = `<div class="error-message">❌ ${message}</div>`;
    console.error("Error:", message);
}

// Función principal para obtener y mostrar usuarios
async function fetchAndDisplayUsers() {
    showLoading();

    try {
        // Consumir API pública de JSONPlaceholder
        const response = await fetch("https://jsonplaceholder.typicode.com/users");

        // Verificar si la respuesta es exitosa
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const users = await response.json();

        // Limpiar contenedor
        usersContainer.innerHTML = "";

        // Mostrar al menos 5 registros (mostraremos todos, que son 10)
        // Pero aseguramos que sean al menos 5
        if (users.length === 0) {
            throw new Error("No se encontraron usuarios");
        }

        // Recorrer y crear tarjetas
        users.forEach(user => {
            const card = document.createElement("div");
            card.classList.add("user-card");

            // Mostrar nombre + dato adicional (email y ciudad)
            card.innerHTML = `
                <h2>👤 ${user.name}</h2>
                <p><strong>📧 Email:</strong> ${user.email}</p>
                <p><strong>🏙️ Ciudad:</strong> ${user.address.city}</p>
                <p><strong>📞 Teléfono:</strong> ${user.phone}</p>
                <p><strong>🏢 Empresa:</strong> ${user.company.name}</p>
            `;
            usersContainer.appendChild(card);
        });

        // Cambiar título dinámico
        apiTitle.textContent = `📡 Usuarios - JSONPlaceholder (${users.length} registros)`;

    } catch (error) {
        showError("Hubo un problema al cargar los datos. " + error.message);
        apiTitle.textContent = "⚠️ Error al cargar API";
    }
}

// Cargar datos al iniciar la página
fetchAndDisplayUsers();

// Botón para recargar información
reloadBtn.addEventListener("click", () => {
    fetchAndDisplayUsers();
});