// ========== VARIABLES GLOBALES ==========
let historial = [];

// ========== FUNCIONES PRINCIPALES ==========

// Función para calcular según la operación seleccionada
function calcular() {
    // 1. Obtener valores del DOM
    let num1Input = document.getElementById("num1");
    let num2Input = document.getElementById("num2");
    let operacionSelect = document.getElementById("operacion");
    
    let num1 = parseFloat(num1Input.value);
    let num2 = parseFloat(num2Input.value);
    let operacion = operacionSelect.value;
    
    const expressionDiv = document.getElementById("expression");
    const resultadoDiv = document.getElementById("resultado");
    const num2Group = document.getElementById("num2-group");
    
    // 2. Validar entrada para raíz cuadrada (solo necesita num1)
    if (operacion === "raiz") {
        if (isNaN(num1) || num1 < 0) {
            mostrarError("Ingresa un número válido mayor o igual a 0");
            return;
        }
        
        let resultado = calcularRaiz(num1);
        let expresionText = `√${num1}`;
        
        expressionDiv.innerHTML = expresionText;
        resultadoDiv.innerHTML = resultado;
        
        // Guardar en historial
        guardarEnHistorial(expresionText, resultado);
        return;
    }
    
    // 3. Validar entrada para operaciones con 2 números
    if (isNaN(num1) || isNaN(num2)) {
        mostrarError("Por favor, completa ambos números");
        return;
    }
    
    // 4. Validar división entre cero
    if (operacion === "dividir" && num2 === 0) {
        mostrarError("Error: No se puede dividir entre cero");
        return;
    }
    
    // 5. Ejecutar la operación correspondiente
    let resultado;
    let expresionText = "";
    
    switch(operacion) {
        case "suma":
            resultado = sumar(num1, num2);
            expresionText = `${num1} + ${num2}`;
            break;
        case "resta":
            resultado = restar(num1, num2);
            expresionText = `${num1} - ${num2}`;
            break;
        case "multiplicar":
            resultado = multiplicar(num1, num2);
            expresionText = `${num1} × ${num2}`;
            break;
        case "dividir":
            resultado = dividir(num1, num2);
            expresionText = `${num1} ÷ ${num2}`;
            break;
        case "potencia":
            resultado = potencia(num1, num2);
            expresionText = `${num1} ^ ${num2}`;
            break;
        default:
            mostrarError("Operación no válida");
            return;
    }
    
    // 6. Mostrar resultado
    expressionDiv.innerHTML = expresionText;
    resultadoDiv.innerHTML = formatResultado(resultado);
    
    // 7. Guardar en historial
    guardarEnHistorial(expresionText, resultado);
    
    // 8. Efecto visual
    resultadoDiv.classList.add("pulse");
    setTimeout(() => resultadoDiv.classList.remove("pulse"), 300);
}

// ========== FUNCIONES DE OPERACIONES BÁSICAS ==========

function sumar(a, b) {
    return a + b;
}

function restar(a, b) {
    return a - b;
}

function multiplicar(a, b) {
    return a * b;
}

function dividir(a, b) {
    if (b === 0) {
        throw new Error("División por cero");
    }
    return a / b;
}

// Función para potencia (operación extra)
function potencia(base, exponente) {
    return Math.pow(base, exponente);
}

// Función para raíz cuadrada (operación extra)
function calcularRaiz(num) {
    if (num < 0) {
        throw new Error("No se puede calcular raíz de número negativo");
    }
    return Math.sqrt(num);
}

// ========== FUNCIONES DE UTILIDAD ==========

// Formatear resultado (evitar decimales excesivos)
function formatResultado(valor) {
    if (typeof valor !== 'number' || isNaN(valor)) {
        return "Error";
    }
    
    // Si es entero, mostrar sin decimales
    if (Number.isInteger(valor)) {
        return valor.toString();
    }
    
    // Limitar a 6 decimales
    return parseFloat(valor.toFixed(6)).toString();
}

// Mostrar mensaje de error
function mostrarError(mensaje) {
    const resultadoDiv = document.getElementById("resultado");
    const expressionDiv = document.getElementById("expression");
    
    resultadoDiv.innerHTML = "❌ Error";
    expressionDiv.innerHTML = mensaje;
    
    // Efecto de error en los inputs
    const inputs = document.querySelectorAll(".calc-input");
    inputs.forEach(input => {
        input.classList.add("error-shake");
        setTimeout(() => input.classList.remove("error-shake"), 500);
    });
    
    // Limpiar después de 2 segundos
    setTimeout(() => {
        if (resultadoDiv.innerHTML === "❌ Error") {
            resultadoDiv.innerHTML = "0";
            expressionDiv.innerHTML = "";
        }
    }, 2000);
}

// ========== FUNCIONES DE HISTORIAL ==========

function guardarEnHistorial(operacion, resultado) {
    const operacionObj = {
        id: Date.now(),
        operacion: operacion,
        resultado: formatResultado(resultado),
        timestamp: new Date().toLocaleTimeString()
    };
    
    historial.unshift(operacionObj); // Agregar al inicio
    actualizarHistorial();
}

function actualizarHistorial() {
    const historyList = document.getElementById("history-list");
    
    if (historial.length === 0) {
        historyList.innerHTML = `
            <div class="empty-history">
                <i class="fas fa-calculator"></i>
                <p>No hay operaciones registradas</p>
            </div>
        `;
        return;
    }
    
    historyList.innerHTML = historial.map(item => `
        <div class="history-item">
            <span class="history-operation">${item.operacion}</span>
            <span class="history-result">= ${item.resultado}</span>
        </div>
    `).join("");
}

function limpiarHistorial() {
    historial = [];
    actualizarHistorial();
}

// ========== FUNCIÓN LIMPIAR TODO ==========

function limpiarTodo() {
    // Limpiar inputs
    document.getElementById("num1").value = "";
    document.getElementById("num2").value = "";
    
    // Resetear display
    document.getElementById("expression").innerHTML = "";
    document.getElementById("resultado").innerHTML = "0";
    
    // Resetear select a suma
    document.getElementById("operacion").value = "suma";
    
    // Mostrar feedback visual
    const btnClear = document.querySelector(".calc-btn.secondary");
    btnClear.style.transform = "scale(0.95)";
    setTimeout(() => {
        btnClear.style.transform = "";
    }, 150);
}

// ========== EVENTO PARA OCULTAR/MOSTRAR NÚMERO 2 ==========
// Cuando se selecciona raíz cuadrada, ocultar el segundo número
document.addEventListener("DOMContentLoaded", function() {
    const operacionSelect = document.getElementById("operacion");
    const num2Group = document.getElementById("num2-group");
    
    function toggleNum2Visibility() {
        if (operacionSelect.value === "raiz") {
            num2Group.style.opacity = "0.5";
            num2Group.style.pointerEvents = "none";
            document.getElementById("num2").value = "";
        } else {
            num2Group.style.opacity = "1";
            num2Group.style.pointerEvents = "auto";
        }
    }
    
    operacionSelect.addEventListener("change", toggleNum2Visibility);
    toggleNum2Visibility();
});

// ========== EFECTOS VISUALES ADICIONALES ==========

// Permitir calcular con Enter
document.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        calcular();
    }
});

// Estilo adicional para animación de resultado
const style = document.createElement('style');
style.textContent = `
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    .pulse {
        animation: pulse 0.3s ease-in-out;
    }
`;
document.head.appendChild(style);